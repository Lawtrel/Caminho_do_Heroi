<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="tie" tilewidth="16" tileheight="16" tilecount="2408" columns="56">
 <image source="../../../../Downloads/10571.png" width="900" height="700"/>
</tileset>
