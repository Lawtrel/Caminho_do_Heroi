package br.lawtrel.hero.screens;

import br.lawtrel.hero.entities.*;
import br.lawtrel.hero.battle.*;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public abstract class BattleScreen implements Screen {
    private BattleSystem battleSystem;
    private SpriteBatch batch;
    private BattleHUD hud;
    private TargetSelector targetSelector;
    private BattleMagicMenu magicMenu;

    public BattleScreen(Player player, Enemy... enemies) {
        this.battleSystem = new BattleSystem(player, enemies);
        this.batch = new SpriteBatch();
    }

    @Override
    public void show() {
        hud = new BattleHUD(battleSystem);
        targetSelector = new TargetSelector();
        magicMenu = new BattleMagicMenu();
        magicMenu.setMagics(player.getKnownMagics());
    }
    @Override
    public void render(float delta) {
        // Desenha fundo, personagens, HUD
        batch.begin();
        for (Enemy enemy : battleSystem.getEnemies()) {
            enemy.render(batch);
        }
        batch.end();

        // Lógica de turnos
        if (battleSystem.getState() == BattleSystem.BattleState.PLAYER_TURN) {
            // Mostra menu de ações
        }
        // Renderiza o HUD por último (sobreposto)
        switch (battleSystem.getState()) {
            case PLAYER_TURN:
                hud.render();
                break;
            case PLAYER_TARGET_SELECT:
                targetSelector.render(batch, font, battleSystem.getEnemies());
                break;
            case PLAYER_MAGIC_SELECT:
                magicMenu.render(batch, font);
                break;
        }
    }
    @Override
    public boolean keyDown(int keycode) {
        switch (battleSystem.getState()) {
            case PLAYER_TURN:
                if (keycode == Input.Keys.DOWN) hud.moveSelection(1);
                if (keycode == Input.Keys.UP) hud.moveSelection(-1);
                if (keycode == Input.Keys.ENTER) hud.selectAction();
                break;
            case PLAYER_TARGET_SELECT:
                if (keycode == Input.Keys.LEFT || keycode == Input.Keys.RIGHT)
                    targetSelector.nextTarget(battleSystem.getEnemies());
                if (keycode == Input.Keys.ENTER)
                    battleSystem.confirmAttack(targetSelector.getSelectedTarget());
                break;
        }
        return true;
    }
}
