package br.lawtrel.hero.battle;

public class BattleState {
}
