package br.lawtrel.hero.battle;

import com.badlogic.gdx.graphics.g2d.*;
import br.lawtrel.hero.magic.*;

public class BattleMagicMenu {
    private Magics[] availableMagics;
    private int selectedMagic = 0;

    public void setMagics(Magics[] magics) {
        this.availableMagics = magics;
    }

    public void render(SpriteBatch batch, BitmapFont font) {
        for (int i = 0; i < availableMagics.length; i++) {
            Magics magic = availableMagics[i];
            String prefix = (i == selectedMagic) ? "> " : "  ";
            String cost = " (" + magic.getCostMP() + " MP)";
            font.draw(batch, prefix + magic.getMagicName() + cost, 50, 150 - (i * 25));
        }
    }

    public Magics getSelectedMagic() {
        return availableMagics[selectedMagic];
    }

    // Métodos para navegação...
}
