package br.lawtrel.hero.entities;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Enemy {
    private Character character;
    private Texture sprite;
    private float x, y;

    public Enemy(Character character, Texture sprite) {
        this.character = character;
        this.sprite = sprite;
    }

    public void setPosition(float x, float y) {
        this.x = x;
        this.y = y;
    }

    public void render(SpriteBatch batch) {
        batch.draw(sprite, x, y);
    }

    public void performAttack(Character target) {
        character.performAttack(target);
    }

    public Character getCharacter() { return character; }
}
