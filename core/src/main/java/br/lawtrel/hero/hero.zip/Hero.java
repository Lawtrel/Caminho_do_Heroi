package br.lawtrel.hero;

import br.lawtrel.hero.entities.Player;
import br.lawtrel.hero.ui.menu.PauseMenuScreen;
import br.lawtrel.hero.utils.MapManager;
import com.badlogic.gdx.Game;
import br.lawtrel.hero.screens.WorldMapScreen;
import com.badlogic.gdx.Screen;

public class Hero extends Game {
    public MapManager mapManager;
    private Screen previousScreen;
    private Player player;

    public void setScreen(Screen screen) {
        this.previousScreen = getScreen();
        super.setScreen(screen);
    }

    public Screen getPreviousScreen() {
        return previousScreen;
    }

    public void pauseGame() {
        setScreen(new PauseMenuScreen(this));
    }

    @Override
    public void create() {
        mapManager = new MapManager(this);
        
        mapManager.changeMap(MapManager.MapType.WORLD_MAP);
        //setScreen(new WorldMapScreen(this, this));
    }

    public Player getPlayer() {
        return null;
    }
}
