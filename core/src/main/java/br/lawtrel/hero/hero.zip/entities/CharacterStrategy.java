package br.lawtrel.hero.entities;

public interface CharacterStrategy {
    void attack(Character self, Character target);
}
