package br.lawtrel.hero.battle;


import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.utils.Align;
import br.lawtrel.hero.entities.*;

public class BattleHUD {
    private BitmapFont font;
    private SpriteBatch batch;
    private BattleSystem battleSystem;

    // Menu de ações
    private String[] menuOptions = {"Atacar", "Magia", "Itens", "Fugir"};
    private int selectedOption = 0;

    public BattleHUD(BattleSystem battleSystem) {
        this.battleSystem = battleSystem;
        this.font = new BitmapFont();
        this.batch = new SpriteBatch();
    }

    public void render() {
        batch.begin();

        // 1. Barra de status dos personagens
        drawCharacterStatus();

        // 2. Menu de ações (se for turno do jogador)
        if (battleSystem.getState() == BattleSystem.BattleState.PLAYER_TURN) {
            drawActionMenu();
        }

        // 3. Mensagens de batalha
        drawBattleMessages();

        batch.end();
    }

    private void drawCharacterStatus() {
        // Player status
        Character player = battleSystem.getPlayer().getCharacter();
        font.draw(batch, player.getName(), 20, Gdx.graphics.getHeight() - 20);
        font.draw(batch, "HP: " + player.getHp() + "/" + player.getMaxHp(), 20, Gdx.graphics.getHeight() - 40);

        // Inimigos status
        Enemy[] enemies = battleSystem.getEnemies();
        for (int i = 0; i < enemies.length; i++) {
            if (enemies[i].getCharacter().isAlive()) {
                font.draw(batch, enemies[i].getCharacter().getName(),
                    Gdx.graphics.getWidth() - 150,
                    Gdx.graphics.getHeight() - 20 - (i * 30));
            }
        }
    }

    private void drawActionMenu() {
        float menuX = 50;
        float menuY = 100;

        for (int i = 0; i < menuOptions.length; i++) {
            String prefix = (i == selectedOption) ? "> " : "  ";
            font.draw(batch, prefix + menuOptions[i], menuX, menuY - (i * 30));
        }
    }

    public void moveSelection(int direction) {
        if (direction > 0) {
            selectedOption = Math.min(menuOptions.length - 1, selectedOption + 1);
        } else {
            selectedOption = Math.max(0, selectedOption - 1);
        }
    }

    public void selectAction() {
        switch (selectedOption) {
            case 0: // Atacar
                battleSystem.enterTargetSelection();
                break;
            case 1: // Magia
                battleSystem.openMagicMenu();
                break;
            case 3: // Fugir
                battleSystem.attemptEscape();
                break;
        }
    }

    public void dispose() {
        font.dispose();
        batch.dispose();
    }
}
