package br.lawtrel.hero.battle;

import br.lawtrel.hero.entities.*;
import br.lawtrel.hero.battle.*;
import java.util.ArrayDeque;
import java.util.Queue;

public class BattleSystem {
    private Player player;
    private Enemy[] enemies;
    private Queue<Character> turnOrder;
    private BattleState state;

    public BattleSystem(Player player, Enemy... enemies) {
        this.player = player;
        this.enemies = enemies;
        this.turnOrder = new ArrayDeque<>();
        this.state = BattleState.PLAYER_TURN;
        calculateTurnOrder();
    }

    public enum BattleState(
        PLAYER_TURN,
        PLAYER_TARGET_SELECT,
        PLAYER_MAGIC_SELECT,
        ENEMY_TURN,
        VICTORY,
        DEFEAT
    )
    public void enterTargetSelection() {
        state = BattleState.PLAYER_TARGET_SELECT;
    }

    public void confirmAttack(int enemyIndex) {
        playerAttack(enemyIndex);
        state = BattleState.ENEMY_TURN;
    }

    private void calculateTurnOrder() {
        //Quem tiver maior velocidade vai primeiro
        turnOrder.clear();
        turnOrder.add(player);
        for (Enemy enemy : enemies) {
            turnOrder.add(enemy);
        }
    }
    public void playerAttack(int enemyIndex) {
        if (state != BattleState.PLAYER_TURN) return;

        Character target = enemies(enemyIndex);
        player.performAttack(target);

        if (!target.isAlive()) {
            // inimigo derrotado
        }
        advanceTurn();
    }

    private void advanceTurn() {
        if (checkBattleEnd()) return;

        turnOrder.poll();
        if (turnOrder.isEmpty()) calculateTurnOrder();

        if (turnOrder.peek() instanceof Enemy) {
            state = BattleState.ENEMY_TURN;
            executeEnemyTurn((Enemy) turnOrder.peek());
        } else {
            state = BattleState.PLAYER_TURN;
        }
    }

    private void executeEnemyTurn(Enemy enemy) {
        //70% chance de ser um ataque normal e 30% chance de ser magia ou critico
        if (Math.random() < 0.3 && enemy.getCharacter().getMP() > 10) {
            // usar alguma magia
        } else {
            enemy.perfomAttack(player.getCharacter());
        }
        advanceTurn();
    }

    private boolean checkBattleEnd() {
        //verificar vitoria e derrota
        return false;
    }
    public enum BattleState {
        PLAYER_TURN, ENEMY_TURN, VICTORY, DEFEAT
    }
}
