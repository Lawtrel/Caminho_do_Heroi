package br.lawtrel.hero.screens;

public class IntroScreen {
}
